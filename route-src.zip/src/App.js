import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link,Navigate } from 'react-router-dom';
import Home from './containers/Home';
import Login from './containers/Login';
import About from './containers/About';
import PageNotFound from './containers/PageNotFound';

const App = () => {
   return (
     <Router>
      <div>
       <h2> Customer App</h2>
          <Link to={'/home'}>Home</Link> | 
          <Link to={'/about'}>About</Link> | 
          <Link to={'/login'}>Logout</Link>
       <hr />
         <Routes>
           <Route exact path="/" element={<Navigate to={{pathname: "/login" }}
        />}/>
           <Route exact path="/login" element={<Login/>}/>
           <Route exact path="/about" element={<About/>}/>
           <Route exact path="/home" element={<Home/>}/>
           <Route path="*" element={<PageNotFound/>}/>
         </Routes>
      </div>
     </Router>
   );
 }
export default App;