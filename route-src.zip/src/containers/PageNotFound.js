import React from 'react';
   function PageNotFound() {
      return (
         <div>
            <h2>Page Not Found</h2>
         </div>
      );
   }
    export default PageNotFound;